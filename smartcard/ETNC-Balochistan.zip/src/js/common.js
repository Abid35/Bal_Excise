document.addEventListener("DOMContentLoaded", function () {
	var firstInput = document.querySelector("form input[name]");
	if (firstInput) firstInput.focus();
});
